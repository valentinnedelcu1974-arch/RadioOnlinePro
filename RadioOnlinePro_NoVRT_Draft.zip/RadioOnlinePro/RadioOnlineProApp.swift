import SwiftUI
import AVFoundation
import AVKit
import MediaPlayer
import Combine

struct Station: Codable, Identifiable, Hashable {
    var id: String { url }
    let name: String
    let genre: String
    let url: String
}
enum StationCatalog {
    // No broadcaster is enabled until commercial integration rights are documented.
    static let permissionURL = URL(string: "https://github.com/valentinnedelcu1974-arch/RadioOnlinePro/blob/main/RIGHTS.md")!
    static let stations: [Station] = []
    static func station(for url: String) -> Station? { stations.first { $0.url == url } }
}

@MainActor final class RadioModel: ObservableObject {
    @Published var stations: [Station] = []
    @Published var discovered: [Station] = StationCatalog.stations
    @Published var current: Station?
    @Published var playing = false
    @Published var buffering = false
    @Published var loading = false
    @Published var favorites: Set<String> = []
    @Published var message = "Alege un post pentru a asculta"
    @Published var directoryMessage = ""
    @Published var sleepDate: Date?
    private let player = AVPlayer()
    private var statusObservation: NSKeyValueObservation?
    private var itemObservation: NSKeyValueObservation?
    private var subscriptions = Set<AnyCancellable>()
    private var sleepTask: Task<Void, Never>?
    private var timeoutTask: Task<Void, Never>?
    private var shouldResume = false

    init() {
        if let data = UserDefaults.standard.data(forKey: "stations"),
           let saved = try? JSONDecoder().decode([Station].self, from: data) {
            stations = saved.compactMap { StationCatalog.station(for: $0.url) }
        }
        favorites = Set(UserDefaults.standard.stringArray(forKey: "favorites") ?? []).intersection(Set(StationCatalog.stations.map(\.id)))
        save()
        statusObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
            let status = player.timeControlStatus
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.playing = status == .playing
                self.buffering = status == .waitingToPlayAtSpecifiedRate
                if status == .playing { self.message = "În direct"; self.timeoutTask?.cancel() }
                else if self.buffering { self.message = "Se conectează…" }
                self.updateNowPlaying()
            }
        }
        NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)
            .receive(on: RunLoop.main).sink { [weak self] note in
                guard let self,
                      let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                      let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
                if type == .began { self.shouldResume = self.playing || self.buffering; self.pause() }
                else {
                    let options = AVAudioSession.InterruptionOptions(rawValue: note.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0)
                    if self.shouldResume && options.contains(.shouldResume) { self.resume() }
                    self.shouldResume = false
                }
            }.store(in: &subscriptions)
        NotificationCenter.default.publisher(for: AVAudioSession.routeChangeNotification)
            .receive(on: RunLoop.main).sink { [weak self] note in
                if let raw = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
                   raw == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue { self?.pause() }
            }.store(in: &subscriptions)
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.resume() }; return .success }
        commands.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.pause() }; return .success }
        commands.togglePlayPauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggle() }; return .success }
        commands.changePlaybackPositionCommand.isEnabled = false
    }
    static func validURL(_ text: String) -> URL? {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    func save() {
        if let data = try? JSONEncoder().encode(stations) { UserDefaults.standard.set(data, forKey: "stations") }
        UserDefaults.standard.set(Array(favorites), forKey: "favorites")
    }
    func remove(_ station: Station) {
        stations.removeAll { $0.id == station.id }; favorites.remove(station.id); save()
    }
    func favorite(_ station: Station) {
        if favorites.contains(station.id) { favorites.remove(station.id) }
        else {
            favorites.insert(station.id)
            if !stations.contains(where: { $0.id == station.id }) { stations.append(station) }
        }
        save()
    }
    func play(_ station: Station) {
        guard StationCatalog.station(for: station.url) != nil, let url = Self.validURL(station.url) else { message = "Fluxul necesită o adresă HTTPS validă."; return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { message = "Sesiunea audio nu poate porni: \(error.localizedDescription)"; return }
        timeoutTask?.cancel(); player.pause(); itemObservation = nil
        current = station; message = "Se conectează…"; buffering = true
        let item = AVPlayerItem(url: url)
        itemObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            guard item.status == .failed else { return }
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === item else { return }
                self.pause(); self.message = "Postul nu este disponibil. Încearcă din nou sau alege alt post."
            }
        }
        player.replaceCurrentItem(with: item); player.play(); updateNowPlaying(); scheduleTimeout()
    }
    private func scheduleTimeout() {
        timeoutTask?.cancel()
        timeoutTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(25)) } catch { return }
            guard let self, self.player.timeControlStatus != .playing else { return }
            self.pause(); self.message = "Conectarea a expirat. Verifică internetul și reîncearcă."
        }
    }
    func pause() {
        timeoutTask?.cancel(); player.pause(); playing = false; buffering = false
        message = "Pauză"; updateNowPlaying()
    }
    func resume() {
        guard current != nil else { return }
        if player.currentItem?.status == .failed, let current { play(current); return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            player.play(); scheduleTimeout()
        } catch { message = error.localizedDescription }
    }
    func toggle() { if playing || buffering { pause() } else { resume() } }
    private func updateNowPlaying() {
        guard let current else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: current.name,
            MPMediaItemPropertyArtist: "Radio Online Pro · \(current.genre)",
            MPNowPlayingInfoPropertyIsLiveStream: true,
            MPNowPlayingInfoPropertyPlaybackRate: playing ? 1.0 : 0.0
        ]
    }
    func sleep(minutes: Int) {
        sleepTask?.cancel(); sleepDate = nil
        guard minutes > 0 else { return }
        sleepDate = Date().addingTimeInterval(Double(minutes * 60))
        sleepTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(minutes * 60)) } catch { return }
            self?.pause(); self?.sleepDate = nil; self?.message = "Temporizator încheiat"
        }
    }

}

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let view = AVRoutePickerView(); view.tintColor = .white; view.activeTintColor = .systemMint; return view
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

struct ContentView: View {
    @StateObject private var model = RadioModel()
    @StateObject private var advertising = AdvertisingModel()
    @State private var search = ""
    @State private var tab = 0
    @State private var info = false
    private let accent = Color(red: 0.30, green: 0.93, blue: 0.76)
    var filtered: [Station] {
        let source = tab == 0 ? model.discovered : model.stations.filter { tab != 1 || model.favorites.contains($0.id) }
        return source.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.genre.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [Color(red: 0.05, green: 0.10, blue: 0.17), .black], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                VStack(spacing: 16) {
                    HStack(spacing: 14) {
                        Image(systemName: "dot.radiowaves.left.and.right").font(.system(size: 35)).foregroundStyle(accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("RADIO ONLINE").font(.title2.bold())
                            Text("Sunetul lumii, oriunde ești.").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }.padding(.horizontal)
                    RadioAdvertisingBanner(advertising: advertising)
                    Picker("Bibliotecă", selection: $tab) {
                        Text("Posturi").tag(0); Text("Favorite").tag(1)
                    }.pickerStyle(.segmented).padding(.horizontal)
                    Text("Catalog în pregătire · fără posturi VRT").font(.caption).foregroundStyle(.secondary).padding(.horizontal)
                    if model.loading && tab == 0 { ProgressView("Se încarcă posturile…").padding() }
                    if tab == 0 && !model.directoryMessage.isEmpty { Text(model.directoryMessage).font(.footnote).foregroundStyle(.secondary).padding(.horizontal) }
                    List {
                        if filtered.isEmpty && !model.loading {
                            ContentUnavailableView(tab == 1 ? "Favoritele tale" : "Catalog în pregătire", systemImage: tab == 1 ? "heart" : "radio", description: Text(tab == 1 ? "Apasă inima de lângă un post pentru a-l salva aici." : "Nu sunt încă disponibile posturi în această versiune. Vor fi adăugate surse cu drepturi verificate."))
                                .listRowBackground(Color.clear)
                        }
                        ForEach(filtered) { station in
                            HStack(spacing: 12) {
                                Button { model.play(station) } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: model.current?.id == station.id && model.playing ? "waveform" : "play.fill")
                                            .foregroundStyle(accent).frame(width: 38, height: 42).background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(station.name).font(.headline).foregroundStyle(.white)
                                            Text(station.genre).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                        }
                                        Spacer(minLength: 0)
                                    }.contentShape(Rectangle())
                                }.buttonStyle(.plain).accessibilityLabel("Ascultă \(station.name)")
                                Button { model.favorite(station) } label: {
                                    Image(systemName: model.favorites.contains(station.id) ? "heart.fill" : "heart").foregroundStyle(model.favorites.contains(station.id) ? .pink : .gray).padding(8)
                                }.buttonStyle(.borderless).accessibilityLabel("Favorite: \(station.name)")
                            }.padding(.vertical, 4).listRowBackground(Color.white.opacity(0.035))
                                .swipeActions { if tab != 0 { Button("Șterge", role: .destructive) { model.remove(station) } } }
                        }
                    }.listStyle(.plain).scrollContentBackground(.hidden)
                }.padding(.top, 12)
            }
            .navigationTitle("Radio Online Pro").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button { info = true } label: { Image(systemName: "info.circle") }.accessibilityLabel("Despre aplicație") }
            }
            .searchable(text: $search, prompt: "Caută posturi sau muzică")
            .safeAreaInset(edge: .bottom) { playerPanel }
            .sheet(isPresented: $info) { about }
            .task { advertising.activate() }
        }.tint(accent).preferredColorScheme(.dark)
    }
    private var playerPanel: some View {
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                Image(systemName: "radio.fill").font(.title).foregroundStyle(accent)
                VStack(alignment: .leading, spacing: 4) {
                    Text(model.current?.name ?? "Pregătit de ascultare").font(.headline).lineLimit(1)
                    Text(model.message).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                }
                Spacer(minLength: 0)
                if model.buffering { ProgressView().accessibilityLabel("Conectare") }
                Button { model.toggle() } label: {
                    Image(systemName: model.playing || model.buffering ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 46))
                }.disabled(model.current == nil).accessibilityLabel(model.playing || model.buffering ? "Pauză" : "Redă")
            }
            HStack {
                Menu {
                    ForEach([15, 30, 60, 90], id: \.self) { minutes in Button("\(minutes) minute") { model.sleep(minutes: minutes) } }
                    Button("Anulează temporizator") { model.sleep(minutes: 0) }
                } label: { Label("Sleep", systemImage: "moon.zzz") }.accessibilityLabel("Temporizator de oprire")
                if let date = model.sleepDate { Text(date, style: .timer).monospacedDigit().font(.caption) }
                Spacer()
                if let current = model.current { Button { model.play(current) } label: { Image(systemName: "arrow.clockwise") }.accessibilityLabel("Reconectează") }
                AirPlayButton().frame(width: 36, height: 30).accessibilityLabel("AirPlay")
            }.font(.subheadline)
        }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)).padding(.horizontal, 12).padding(.bottom, 5)
    }
    private var about: some View {
        NavigationStack {
            Form {
                Section("Radio Online Pro · 1.0") { Text("Player radio pentru iPhone, cu favorite, redare în fundal, AirPlay și temporizator. Nu este necesar un cont.") }
                Section("Confidențialitate") { Text("Posturile și favoritele sunt salvate doar pe dispozitiv. Publicitatea comercială este dezactivată. Dacă pornești testarea publicitară, Google poate primi adresa IP, identificatori tehnici și date despre afișarea reclamelor. Nu solicităm acces la IDFA; solicitările sunt nepersonalizate. Nu folosim analiză de utilizare. Căutarea se efectuează pe dispozitiv. La redare, serverele posturilor primesc adresa IP și datele tehnice necesare conexiunii. Disponibilitatea fluxurilor depinde de posturile radio.") }
                Section("Publicitate") {
                    Text(advertising.status).font(.footnote)
                    if !advertising.configuration.permitsLiveAds {
                        Button("Pornește bannerul de test (Google)") { advertising.activate(test: true) }
                        Text("Opțional. Pornește conexiuni către Google pentru verificarea integrării. Nu generează venituri.").font(.caption)
                        if advertising.canShowBanner { Button("Oprește testul") { advertising.stopTests() } }
                    }
                    if advertising.privacyOptionsRequired {
                        Button("Opțiuni de confidențialitate pentru reclame") { Task { await advertising.privacyOptions() } }
                    }
                    Link("Confidențialitate Google", destination: URL(string: "https://policies.google.com/privacy")!)
                }
                Section("Surse & permisiune") {
                    Link("Registrul drepturilor pentru posturi", destination: StationCatalog.permissionURL)
                    Text("Posturile VRT au fost eliminate din această variantă. Catalogul este în pregătire; vor fi incluse doar surse cu permisiuni verificate pentru utilizarea propusă. Publicitatea comercială rămâne oprită.").font(.footnote)
                }
                Section("Asistență") { Link("Contactează dezvoltatorul", destination: URL(string: "mailto:valentin.nedelcu@icloud.com")!) }
            }.navigationTitle("Despre & confidențialitate").toolbar { Button("Închide") { info = false } }
        }
    }
}

@main struct RadioOnlineProApp: App { var body: some Scene { WindowGroup { ContentView() } } }
