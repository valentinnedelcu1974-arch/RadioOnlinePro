import SwiftUI
import AVFoundation
import AVKit
import MediaPlayer
import Combine

struct Station: Codable, Identifiable, Hashable {
    var id: String { url }
    let name: String
    let genre: String
    let url: String
}
enum StationCatalog {
    // MDK publishes its original music under CC BY 3.0. Live attribution is verified before playback.
    static let permissionURL = URL(string: "https://github.com/valentinnedelcu1974-arch/RadioOnlinePro/blob/main/RIGHTS.md")!
    static func requiresAttribution(_ station: Station) -> Bool { station.url == "https://radio.mdkband.com/stream.mp3" }
    static let stations: [Station] = [
        Station(name: "MDK Space Radio", genre: "Electronică experimentală · CC BY 3.0", url: "https://radio.mdkband.com/stream.mp3"),
        Station(name: "Radio 1", genre: "VRT · Belgia · Actualitate", url: "https://icecast.vrtcdn.be/radio1-high.mp3"),
        Station(name: "Radio 1 Classics", genre: "VRT · Belgia · Clasice", url: "https://icecast.vrtcdn.be/radio1_classics-high.mp3"),
        Station(name: "Radio Bene", genre: "VRT · Belgia · Muzică", url: "https://icecast.vrtcdn.be/radiobene-high.mp3"),
        Station(name: "Radio 2 Antwerpen", genre: "VRT · Belgia · Regional", url: "https://icecast.vrtcdn.be/ra2ant-high.mp3"),
        Station(name: "Radio 2 Limburg", genre: "VRT · Belgia · Regional", url: "https://icecast.vrtcdn.be/ra2lim-high.mp3"),
        Station(name: "Radio 2 Oost-Vlaanderen", genre: "VRT · Belgia · Regional", url: "https://icecast.vrtcdn.be/ra2ovl-high.mp3"),
        Station(name: "Radio 2 Vlaams-Brabant", genre: "VRT · Belgia · Regional", url: "https://icecast.vrtcdn.be/ra2vlb-high.mp3"),
        Station(name: "Radio 2 West-Vlaanderen", genre: "VRT · Belgia · Regional", url: "https://icecast.vrtcdn.be/ra2wvl-high.mp3"),
        Station(name: "Radio 2 Relax", genre: "VRT · Belgia · Relaxare", url: "https://icecast.vrtcdn.be/radio2_relax-high.mp3"),
        Station(name: "Klara", genre: "VRT · Belgia · Clasică", url: "https://icecast.vrtcdn.be/klara-high.mp3"),
        Station(name: "Klara Continuo", genre: "VRT · Belgia · Clasică", url: "https://icecast.vrtcdn.be/klaracontinuo-high.mp3"),
        Station(name: "De Tijdloze", genre: "VRT · Belgia · Muzică", url: "https://icecast.vrtcdn.be/stubru_tijdloze-high.mp3"),
        Station(name: "Studio Brussel", genre: "VRT · Belgia · Alternativ", url: "https://icecast.vrtcdn.be/stubru-high.mp3"),
        Station(name: "Studio Brussel Bruut", genre: "VRT · Belgia · Rock", url: "https://icecast.vrtcdn.be/stubru_bruut-high.mp3"),
        Station(name: "Studio Brussel De Jaren Nul", genre: "VRT · Belgia · Muzică", url: "https://icecast.vrtcdn.be/stubru_dejarennul-high.mp3"),
        Station(name: "Studio Brussel Vuurland", genre: "VRT · Belgia · Muzică", url: "https://icecast.vrtcdn.be/stubru_tgs-high.mp3"),
        Station(name: "Studio Brussel UNTZ", genre: "VRT · Belgia · Electronică", url: "https://icecast.vrtcdn.be/stubru_untz-high.mp3"),
        Station(name: "MNM", genre: "VRT · Belgia · Pop", url: "https://icecast.vrtcdn.be/mnm-high.mp3"),
        Station(name: "MNM Hits", genre: "VRT · Belgia · Hituri", url: "https://icecast.vrtcdn.be/mnm_hits-high.mp3"),
        Station(name: "Ketnet Hits", genre: "VRT · Belgia · Familie", url: "https://icecast.vrtcdn.be/ketnetradio-high.mp3"),
        Station(name: "VRT NWS", genre: "VRT · Belgia · Știri", url: "https://icecast.vrtcdn.be/vrtnws-high.mp3"),
    ]
    static func station(for url: String) -> Station? { stations.first { $0.url == url } }
}

@MainActor final class RadioModel: ObservableObject {
    @Published var stations: [Station] = []
    @Published var discovered: [Station] = StationCatalog.stations
    @Published var current: Station?
    @Published var playing = false
    @Published var buffering = false
    @Published var loading = false
    @Published var favorites: Set<String> = []
    @Published var message = "Alege un post pentru a asculta"
    @Published var directoryMessage = ""
    @Published var sleepDate: Date?
    @Published private(set) var attribution: MDKAttribution?
    private var attributionTask: Task<Void, Never>?
    private var playbackGeneration = UUID()
    private let player = AVPlayer()
    private var statusObservation: NSKeyValueObservation?
    private var itemObservation: NSKeyValueObservation?
    private var subscriptions = Set<AnyCancellable>()
    private var sleepTask: Task<Void, Never>?
    private var timeoutTask: Task<Void, Never>?
    private var shouldResume = false

    init() {
        if let data = UserDefaults.standard.data(forKey: "stations"),
           let saved = try? JSONDecoder().decode([Station].self, from: data) {
            stations = saved.compactMap { StationCatalog.station(for: $0.url) }
        }
        favorites = Set(UserDefaults.standard.stringArray(forKey: "favorites") ?? []).intersection(Set(StationCatalog.stations.map(\.id)))
        save()
        statusObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
            let status = player.timeControlStatus
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.playing = status == .playing
                self.buffering = status == .waitingToPlayAtSpecifiedRate
                if status == .playing { self.message = "În direct"; self.timeoutTask?.cancel() }
                else if self.buffering { self.message = "Se conectează…" }
                self.updateNowPlaying()
            }
        }
        NotificationCenter.default.publisher(for: AVAudioSession.interruptionNotification)
            .receive(on: RunLoop.main).sink { [weak self] note in
                guard let self,
                      let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                      let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
                if type == .began { self.shouldResume = self.playing || self.buffering; self.pause() }
                else {
                    let options = AVAudioSession.InterruptionOptions(rawValue: note.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0)
                    if self.shouldResume && options.contains(.shouldResume) { self.resume() }
                    self.shouldResume = false
                }
            }.store(in: &subscriptions)
        NotificationCenter.default.publisher(for: AVAudioSession.routeChangeNotification)
            .receive(on: RunLoop.main).sink { [weak self] note in
                if let raw = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt,
                   raw == AVAudioSession.RouteChangeReason.oldDeviceUnavailable.rawValue { self?.pause() }
            }.store(in: &subscriptions)
        let commands = MPRemoteCommandCenter.shared()
        commands.playCommand.addTarget { [weak self] _ in Task { @MainActor in self?.resume() }; return .success }
        commands.pauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.pause() }; return .success }
        commands.togglePlayPauseCommand.addTarget { [weak self] _ in Task { @MainActor in self?.toggle() }; return .success }
        commands.changePlaybackPositionCommand.isEnabled = false
    }
    static func validURL(_ text: String) -> URL? {
        guard let url = URL(string: text.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    func save() {
        if let data = try? JSONEncoder().encode(stations) { UserDefaults.standard.set(data, forKey: "stations") }
        UserDefaults.standard.set(Array(favorites), forKey: "favorites")
    }
    func remove(_ station: Station) {
        stations.removeAll { $0.id == station.id }; favorites.remove(station.id); save()
    }
    func favorite(_ station: Station) {
        if favorites.contains(station.id) { favorites.remove(station.id) }
        else {
            favorites.insert(station.id)
            if !stations.contains(where: { $0.id == station.id }) { stations.append(station) }
        }
        save()
    }
    func play(_ station: Station) {
        guard StationCatalog.station(for: station.url) != nil else { return }
        attributionTask?.cancel(); player.pause(); timeoutTask?.cancel()
        playbackGeneration = UUID()
        let generation = playbackGeneration
        current = station; attribution = nil; playing = false; buffering = true
        if !StationCatalog.requiresAttribution(station) { beginPlayback(station); return }
        message = "Se verifică informațiile piesei…"
        attributionTask = Task { [weak self] in
            var started = false
            while !Task.isCancelled {
                do {
                    let credit = try await MDKAttribution.load()
                    try Task.checkCancellation()
                    guard let self, self.playbackGeneration == generation else { return }
                    self.attribution = credit
                    if !started { self.beginPlayback(station); started = true }
                    self.updateNowPlaying()
                } catch is CancellationError { return }
                  catch {
                    guard let self, self.playbackGeneration == generation else { return }
                    self.pause()
                    self.message = "Informațiile piesei nu pot fi verificate. Reîncearcă mai târziu."
                    return
                }
                do { try await Task.sleep(for: .seconds(20)) } catch { return }
            }
        }
    }
    private func beginPlayback(_ station: Station) {
        guard StationCatalog.station(for: station.url) != nil, let url = Self.validURL(station.url) else { message = "Fluxul necesită o adresă HTTPS validă."; return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch { message = "Sesiunea audio nu poate porni: \(error.localizedDescription)"; return }
        timeoutTask?.cancel(); player.pause(); itemObservation = nil
        current = station; message = "Se conectează…"; buffering = true
        let item = AVPlayerItem(url: url)
        itemObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            guard item.status == .failed else { return }
            Task { @MainActor [weak self] in
                guard let self, self.player.currentItem === item else { return }
                self.pause(); self.message = "Postul nu este disponibil. Încearcă din nou sau alege alt post."
            }
        }
        player.replaceCurrentItem(with: item); player.play(); updateNowPlaying(); scheduleTimeout()
    }
    private func scheduleTimeout() {
        timeoutTask?.cancel()
        timeoutTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(25)) } catch { return }
            guard let self, self.player.timeControlStatus != .playing else { return }
            self.pause(); self.message = "Conectarea a expirat. Verifică internetul și reîncearcă."
        }
    }
    func pause() {
        attributionTask?.cancel(); playbackGeneration = UUID()
        timeoutTask?.cancel(); player.pause(); playing = false; buffering = false
        message = "Pauză"; updateNowPlaying()
    }
    func resume() { if let current { play(current) } }
    func toggle() { if playing || buffering { pause() } else { resume() } }
    private func updateNowPlaying() {
        guard let current else { return }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = [
            MPMediaItemPropertyTitle: attribution?.trackTitle ?? current.name,
            MPMediaItemPropertyArtist: attribution?.artist ?? current.genre,
            MPMediaItemPropertyAlbumTitle: attribution?.releaseTitle ?? current.name,
            MPNowPlayingInfoPropertyIsLiveStream: true,
            MPNowPlayingInfoPropertyPlaybackRate: playing ? 1.0 : 0.0
        ]
    }
    func sleep(minutes: Int) {
        sleepTask?.cancel(); sleepDate = nil
        guard minutes > 0 else { return }
        sleepDate = Date().addingTimeInterval(Double(minutes * 60))
        sleepTask = Task { [weak self] in
            do { try await Task.sleep(for: .seconds(minutes * 60)) } catch { return }
            self?.pause(); self?.sleepDate = nil; self?.message = "Temporizator încheiat"
        }
    }

}

struct AirPlayButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let view = AVRoutePickerView(); view.tintColor = .white; view.activeTintColor = .systemMint; return view
    }
    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

struct ContentView: View {
    @StateObject private var model = RadioModel()
    @State private var search = ""
    @State private var tab = 0
    @State private var info = false
    @State private var notebook = false
    private let accent = Color(red: 0.30, green: 0.93, blue: 0.76)
    var filtered: [Station] {
        let source = tab == 0 ? model.discovered : model.stations.filter { tab != 1 || model.favorites.contains($0.id) }
        return source.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.genre.localizedCaseInsensitiveContains(search) }
    }
    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(colors: [Color(red: 0.05, green: 0.10, blue: 0.17), .black], startPoint: .topLeading, endPoint: .bottomTrailing).ignoresSafeArea()
                VStack(spacing: 16) {
                    HStack(spacing: 14) {
                        Image(systemName: "dot.radiowaves.left.and.right").font(.system(size: 35)).foregroundStyle(accent)
                        VStack(alignment: .leading, spacing: 3) {
                            Text("RADIO 43").font(.title2.bold())
                            Text("Sunetul lumii, oriunde ești.").font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                    }.padding(.horizontal)
                    Picker("Bibliotecă", selection: $tab) {
                        Text("Posturi").tag(0); Text("Favorite").tag(1)
                    }.pickerStyle(.segmented).padding(.horizontal)
                    Text("Gratuit · fără reclame · fluxuri oficiale").font(.caption).foregroundStyle(.secondary).padding(.horizontal)
                    if model.loading && tab == 0 { ProgressView("Se încarcă posturile…").padding() }
                    if tab == 0 && !model.directoryMessage.isEmpty { Text(model.directoryMessage).font(.footnote).foregroundStyle(.secondary).padding(.horizontal) }
                    List {
                        if filtered.isEmpty && !model.loading {
                            ContentUnavailableView(tab == 1 ? "Favoritele tale" : "Catalog în pregătire", systemImage: tab == 1 ? "heart" : "radio", description: Text(tab == 1 ? "Apasă inima de lângă un post pentru a-l salva aici." : "Niciun rezultat. Încearcă altă căutare."))
                                .listRowBackground(Color.clear)
                        }
                        ForEach(filtered) { station in
                            HStack(spacing: 12) {
                                Button { model.play(station) } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: model.current?.id == station.id && model.playing ? "waveform" : "play.fill")
                                            .foregroundStyle(accent).frame(width: 38, height: 42).background(accent.opacity(0.12), in: RoundedRectangle(cornerRadius: 12))
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(station.name).font(.headline).foregroundStyle(.white)
                                            Text(station.genre).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                                        }
                                        Spacer(minLength: 0)
                                    }.contentShape(Rectangle())
                                }.buttonStyle(.plain).accessibilityLabel("Ascultă \(station.name)")
                                Button { model.favorite(station) } label: {
                                    Image(systemName: model.favorites.contains(station.id) ? "heart.fill" : "heart").foregroundStyle(model.favorites.contains(station.id) ? .pink : .gray).padding(8)
                                }.buttonStyle(.borderless).accessibilityLabel("Favorite: \(station.name)")
                            }.padding(.vertical, 4).listRowBackground(Color.white.opacity(0.035))
                                .swipeActions { if tab != 0 { Button("Șterge", role: .destructive) { model.remove(station) } } }
                        }
                    }.listStyle(.plain).scrollContentBackground(.hidden)
                }.padding(.top, 12)
            }
            .navigationTitle("Radio 43").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { Button { notebook = true } label: { Image(systemName: "book.closed") }.accessibilityLabel("Jurnal și proveniență muzicală") }
                ToolbarItem(placement: .topBarLeading) { Button { info = true } label: { Image(systemName: "info.circle") }.accessibilityLabel("Despre aplicație") }
            }
            .searchable(text: $search, prompt: "Caută posturi sau muzică")
            .safeAreaInset(edge: .bottom) { playerPanel }
            .sheet(isPresented: $info) { about }
            .sheet(isPresented: $notebook) { ListeningNotebook(current: model.attribution) }
        }.tint(accent).preferredColorScheme(.dark)
    }
    private var playerPanel: some View {
        VStack(spacing: 10) {
            if model.current.map(StationCatalog.requiresAttribution) ?? false {
            VStack(alignment: .leading, spacing: 3) {
                Text(model.attribution.map { "\($0.trackTitle) · \($0.releaseTitle)" } ?? "MDK Space Radio")
                    .font(.caption).lineLimit(2)
                Text("Music by MDK · Mik Schuppin, Diego Madero & Kai Kraatz")
                    .font(.caption2).foregroundStyle(.secondary)
                HStack {
                    Link("Sursa muzicii", destination: model.attribution?.sourceURL ?? URL(string: "https://radio.mdkband.com/")!)
                    Link("CC BY 3.0 · audio nemodificat", destination: URL(string: "https://creativecommons.org/licenses/by/3.0/")!)
                }.font(.caption2)
            }.frame(maxWidth: .infinity, alignment: .leading)
            } else if model.current != nil {
                Link("Sursa oficială VRT · ascultare gratuită", destination: URL(string: "https://www.vrt.be/nl/ons-aanbod/streamingslinks-radio")!).font(.caption)
            }
            HStack(spacing: 12) {
                Image(systemName: "radio.fill").font(.title).foregroundStyle(accent)
                VStack(alignment: .leading, spacing: 4) {
                    Text(model.current?.name ?? "Pregătit de ascultare").font(.headline).lineLimit(1)
                    Text(model.message).font(.caption).foregroundStyle(.secondary).lineLimit(2)
                }
                Spacer(minLength: 0)
                if model.buffering { ProgressView().accessibilityLabel("Conectare") }
                Button { model.toggle() } label: {
                    Image(systemName: model.playing || model.buffering ? "pause.circle.fill" : "play.circle.fill").font(.system(size: 46))
                }.disabled(model.current == nil).accessibilityLabel(model.playing || model.buffering ? "Pauză" : "Redă")
            }
            HStack {
                Menu {
                    ForEach([15, 30, 60, 90], id: \.self) { minutes in Button("\(minutes) minute") { model.sleep(minutes: minutes) } }
                    Button("Anulează temporizator") { model.sleep(minutes: 0) }
                } label: { Label("Sleep", systemImage: "moon.zzz") }.accessibilityLabel("Temporizator de oprire")
                if let date = model.sleepDate { Text(date, style: .timer).monospacedDigit().font(.caption) }
                Spacer()
                if let current = model.current { Button { model.play(current) } label: { Image(systemName: "arrow.clockwise") }.accessibilityLabel("Reconectează") }
                AirPlayButton().frame(width: 36, height: 30).accessibilityLabel("AirPlay")
            }.font(.subheadline)
        }.padding(16).background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22)).padding(.horizontal, 12).padding(.bottom, 5)
    }
    private var about: some View {
        NavigationStack {
            Form {
                Section("Radio 43 · 1.0") { Text("Player radio pentru iPhone, cu favorite, redare în fundal, AirPlay și temporizator. Nu este necesar un cont.") }
                Section("Confidențialitate") { Text("Fără reclame, SDK publicitar, analiză de utilizare, conturi sau abonamente. Posturile, favoritele și jurnalul sunt salvate pe dispozitiv. La redare, serverele posturilor primesc adresa IP și datele tehnice ale conexiunii. Legăturile către surse se deschid în browser. Nu înregistrăm și nu descărcăm audio.") }
                Section("Posturi VRT") {
                    Text("21 de fluxuri publicate de VRT pentru ascultare prin aplicații terțe. Redare directă, nemodificată, fără publicitate adăugată și fără abonament. Radio 43 nu este afiliată sau aprobată de VRT. Emisiunile pot conține publicitatea proprie a radiodifuzorului.")
                    Link("Adrese oficiale VRT", destination: URL(string: "https://www.vrt.be/nl/ons-aanbod/streamingslinks-radio")!)
                    Link("Condiții VRT", destination: URL(string: "https://www.vrt.be/nl/info/gebruiksvoorwaarden")!)
                }
                Section("Muzică & credite") {
                    Text("Music by MDK — Mik Schuppin, Diego Madero & Kai Kraatz. Licență CC BY 3.0. Fluxul audio este redat direct, fără modificare. Aplicația nu este afiliată și nu este aprobată de MDK.")
                    Link("Sursa originală MDK Space Radio", destination: URL(string: "https://radio.mdkband.com/")!)
                    Link("Creative Commons Attribution 3.0", destination: URL(string: "https://creativecommons.org/licenses/by/3.0/")!)
                }
                Section("Surse & permisiune") {
                    Link("Registrul drepturilor pentru posturi", destination: StationCatalog.permissionURL)
                    Text("Catalogul include 21 de posturi VRT și MDK Space Radio. Verificarea licenței piesei și jurnalul pieselor se aplică numai canalului MDK. Pentru VRT, redarea este directă din fluxurile publicate de radiodifuzor. Fără publicitate adăugată de aplicație.").font(.footnote)
                }
                Section("Asistență") { Link("Contactează dezvoltatorul", destination: URL(string: "mailto:valentin.nedelcu@icloud.com")!) }
            }.navigationTitle("Despre & confidențialitate").toolbar { Button("Închide") { info = false } }
        }
    }
}

@main struct RadioOnlineProApp: App { var body: some Scene { WindowGroup { ContentView() } } }
