import SwiftUI

struct ListeningEntry: Codable, Identifiable {
    var id = UUID()
    let track: String
    let album: String
    let source: String
    let savedAt: Date
    var note = ""
    var citation: String {
        "\(track) — \(album)\nMusic by MDK — Mik Schuppin, Diego Madero & Kai Kraatz.\nSource: \(source)\nLicense: \(MDKAttribution.licenseURL)\nAudio unchanged. No endorsement implied."
    }
}

struct ListeningNotebook: View {
    let current: MDKAttribution?
    @Environment(\.dismiss) private var dismiss
    @AppStorage("radio.listeningNotebook.v1") private var stored = "[]"
    @State private var search = ""
    @State private var selection = 0
    @State private var failure = false
    private var entries: [ListeningEntry] {
        (try? JSONDecoder().decode([ListeningEntry].self, from: Data(stored.utf8))) ?? []
    }
    private func save(_ value: [ListeningEntry]) {
        guard let data = try? JSONEncoder().encode(value), let text = String(data: data, encoding: .utf8) else { failure = true; return }
        stored = text
    }
    private func bookmark() {
        guard let credit = current, (try? credit.validated()) != nil else { failure = true; return }
        var value = entries
        guard !value.contains(where: { $0.track == credit.trackTitle && $0.source == credit.archiveDetailsURL }) else { return }
        value.insert(ListeningEntry(track: credit.trackTitle, album: credit.releaseTitle, source: credit.archiveDetailsURL, savedAt: Date()), at: 0)
        save(value)
    }
    var body: some View {
        NavigationStack {
            List {
                Section {
                    Text("Un jurnal local de descoperire muzicală. Salvăm doar textul și sursa verificată; fără înregistrare sau descărcare audio.").font(.footnote)
                    if let current {
                        Text(current.trackTitle).font(.headline)
                        Text(current.releaseTitle).foregroundStyle(.secondary)
                        Button("Salvează piesa verificată în jurnal", action: bookmark)
                    }
                    Picker("Conținut", selection: $selection) {
                        Text("Jurnal").tag(0)
                        Text("Registru albume").tag(1)
                    }.pickerStyle(.segmented)
                }
                if selection == 0 {
                    if entries.isEmpty {
                        Text("Pornește radioul și salvează o piesă pentru a adăuga notițe și a exporta atribuirea.")
                    }
                    ForEach(entries.filter { search.isEmpty || ($0.track + $0.album + $0.note).localizedCaseInsensitiveContains(search) }) { entry in
                        NavigationLink {
                            Form {
                                Section("Piesă salvată") {
                                    Text(entry.track).font(.headline)
                                    Text(entry.album)
                                    Text(entry.savedAt, format: .dateTime)
                                }
                                Section("Notiță personală") {
                                    TextField("Ce ai remarcat la această piesă?", text: Binding(get: {
                                        entries.first(where: { $0.id == entry.id })?.note ?? ""
                                    }, set: { note in
                                        var value = entries
                                        if let index = value.firstIndex(where: { $0.id == entry.id }) { value[index].note = note; save(value) }
                                    }), axis: .vertical)
                                }
                                Section("Atribuire și proveniență") {
                                    Text(entry.citation).font(.footnote)
                                    if let url = URL(string: entry.source) { Link("Deschide sursa originală", destination: url) }
                                    ShareLink(item: entry.citation) { Label("Exportă atribuirea", systemImage: "square.and.arrow.up") }
                                }
                            }.navigationTitle("Fișa piesei")
                        } label: {
                            VStack(alignment: .leading) { Text(entry.track); Text(entry.album).font(.caption).foregroundStyle(.secondary) }
                        }
                        .swipeActions { Button("Șterge", role: .destructive) { save(entries.filter { $0.id != entry.id }) } }
                    }
                } else {
                    Section("Registru local de licențe • \(MDKAttribution.licensedReleases.count) albume") {
                        Text("Referințe de proveniență, nu posturi radio suplimentare. Consultă sursa fiecărui album pentru titluri și detalii.").font(.footnote)
                        ForEach(MDKAttribution.licensedReleases.keys.sorted().filter { search.isEmpty || ($0 + (MDKAttribution.licensedReleases[$0]?.sourceURL ?? "")).localizedCaseInsensitiveContains(search) }, id: \.self) { id in
                            if let release = MDKAttribution.licensedReleases[id], let url = URL(string: release.sourceURL) {
                                NavigationLink {
                                    Form {
                                        Text(id).font(.headline)
                                        Text("Music by MDK — Mik Schuppin, Diego Madero & Kai Kraatz")
                                        Text(release.sourceURL).textSelection(.enabled)
                                        Link("Sursa albumului", destination: url)
                                        Link("Licență CC BY 3.0", destination: URL(string: release.licenseURL)!)
                                        Text("Licența permite utilizare comercială cu respectarea atribuirii. Nu implică aprobarea aplicației de către artiști.").font(.footnote)
                                        ShareLink(item: "Music by MDK — Mik Schuppin, Diego Madero & Kai Kraatz. Source: \(release.sourceURL). License: \(release.licenseURL). Audio unchanged; no endorsement implied.") { Text("Exportă referința albumului") }
                                    }.navigationTitle("Proveniență album")
                                } label: { VStack(alignment: .leading) { Text(id); Text(url.lastPathComponent).font(.caption).lineLimit(2) } }
                            }
                        }
                    }
                }
            }
            .navigationTitle("Jurnal & proveniență")
            .searchable(text: $search, prompt: "Caută piesă, notiță sau album")
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Închide") { dismiss() } } }
            .alert("Salvarea nu este disponibilă", isPresented: $failure) { Button("OK", role: .cancel) {} } message: { Text("Încearcă din nou după verificarea metadatelor piesei curente.") }
        }
    }
}
