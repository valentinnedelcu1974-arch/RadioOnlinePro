# No-VRT advertising draft

AdMob integration and registered identifiers are retained. Live ads remain disabled and are additionally blocked for an empty catalog. EU/US messages and the developer website were configured previously. New broadcaster rights, populated catalog, privacy/listing updates, Xcode validation and provider/store approval are still required. No live revenue claimed.
