import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
}
