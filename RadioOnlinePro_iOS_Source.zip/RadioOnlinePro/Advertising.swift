import SwiftUI
import GoogleMobileAds
import UserMessagingPlatform

/// Production is fail-closed: publisher configuration, consent and commercial
/// streaming permission are independent requirements, never inferred from a URL.
struct AdvertisingConfiguration {
    static let testAppID = "ca-app-pub-3940256099942544~1458002511"
    static let testBannerID = "ca-app-pub-3940256099942544/2435281174"
    let appID: String
    let bannerID: String
    let commercialRightsConfirmed: Bool
    let publisherSetupComplete: Bool
    var permitsLiveAds: Bool {
        !StationCatalog.stations.isEmpty && commercialRightsConfirmed && publisherSetupComplete &&
        Self.validID(appID, separator: "~") && Self.validID(bannerID, separator: "/") &&
        !appID.hasPrefix("ca-app-pub-3940256099942544") &&
        !bannerID.hasPrefix("ca-app-pub-3940256099942544")
    }
    var permitsTestAds: Bool { Self.validID(appID, separator: "~") }
    private static func validID(_ value: String, separator: Character) -> Bool {
        guard value.hasPrefix("ca-app-pub-") else { return false }
        let parts = value.dropFirst(11).split(separator: separator, omittingEmptySubsequences: false)
        return parts.count == 2 && parts[0].count == 16 && parts[1].count == 10 &&
            parts.allSatisfy { $0.allSatisfy(\.isNumber) }
    }
    static var current: Self {
        let info = Bundle.main.infoDictionary ?? [:]
        return Self(appID: info["GADApplicationIdentifier"] as? String ?? "",
                    bannerID: info["RadioBannerAdUnitID"] as? String ?? "",
                    commercialRightsConfirmed: info["RadioCommercialRightsConfirmed"] as? Bool ?? false,
                    publisherSetupComplete: info["RadioPublisherSetupComplete"] as? Bool ?? false)
    }
}

@MainActor final class AdvertisingModel: ObservableObject {
    @Published private(set) var canShowBanner = false
    @Published private(set) var privacyOptionsRequired = false
    @Published private(set) var status = "Publicitatea comercială nu este activată."
    @Published private(set) var isTest = false
    @Published private(set) var bannerGeneration = UUID()
    private var started = false
    private var gathering = false
    private var enabled = false
    let configuration = AdvertisingConfiguration.current
    var bannerID: String { isTest ? AdvertisingConfiguration.testBannerID : configuration.bannerID }

    func activate(test: Bool = false) {
        guard !gathering, test ? configuration.permitsTestAds : configuration.permitsLiveAds else { return }
        // Test requests always use Google's sample banner, even with the owner's real app ID for UMP.
        isTest = test
        enabled = true
        gathering = true
        canShowBanner = false
        status = "Se verifică opțiunile de confidențialitate…"
        ConsentInformation.shared.requestConsentInfoUpdate(with: RequestParameters()) { [weak self] error in
            Task { @MainActor in
                guard let self else { return }
                defer { self.gathering = false }
                guard error == nil else {
                    self.status = "Reclamele sunt indisponibile. Radioul poate fi folosit în continuare."
                    return
                }
                do {
                    try await ConsentForm.loadAndPresentIfRequired(from: nil)
                    self.refreshPermission()
                } catch {
                    self.status = "Consimțământul nu a putut fi verificat. Reclamele rămân oprite."
                }
            }
        }
    }
    private func refreshPermission() {
        privacyOptionsRequired = ConsentInformation.shared.privacyOptionsRequirementStatus == .required
        guard enabled, ConsentInformation.shared.canRequestAds else {
            canShowBanner = false
            status = "Reclamele nu sunt disponibile pentru opțiunile curente."
            return
        }
        if !started {
            MobileAds.shared.requestConfiguration.setPublisherFirstPartyIDEnabled(false)
            MobileAds.shared.start()
            started = true
        }
        bannerGeneration = UUID()
        canShowBanner = true
        status = isTest ? "Mod test Google: fără venituri și fără reclame comerciale." : "Publicitate activată."
    }
    func privacyOptions() async {
        canShowBanner = false
        do {
            try await ConsentForm.presentPrivacyOptionsForm(from: nil)
            refreshPermission()
        } catch {
            status = "Opțiunile nu pot fi încărcate. Reclamele rămân oprite."
        }
    }
    func stopTests() {
        enabled = false
        canShowBanner = false
        status = "Testul publicitar este oprit."
    }
}

struct RadioAdvertisingBanner: View {
    @ObservedObject var advertising: AdvertisingModel
    var body: some View {
        if advertising.canShowBanner {
            VStack(spacing: 6) {
                Text(advertising.isTest ? "PUBLICITATE · TEST FĂRĂ VENITURI" : "PUBLICITATE")
                    .font(.caption2).foregroundStyle(.secondary)
                GeometryReader { geometry in
                    BannerRepresentable(adUnitID: advertising.bannerID, width: geometry.size.width)
                }.frame(height: currentOrientationAnchoredAdaptiveBanner(width: UIScreen.main.bounds.width - 32).size.height)
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            .id(advertising.bannerGeneration)
        }
    }
}

private struct BannerRepresentable: UIViewRepresentable {
    let adUnitID: String
    let width: CGFloat
    func makeUIView(context: Context) -> BannerView {
        let banner = BannerView(adSize: currentOrientationAnchoredAdaptiveBanner(width: width))
        banner.adUnitID = adUnitID
        // SDK 13 resolves the presenting controller for SwiftUI automatically.
        let request = Request()
        let extras = Extras()
        extras.additionalParameters = ["npa": "1"]
        request.register(extras)
        banner.load(request)
        return banner
    }
    func updateUIView(_ uiView: BannerView, context: Context) {}
}
