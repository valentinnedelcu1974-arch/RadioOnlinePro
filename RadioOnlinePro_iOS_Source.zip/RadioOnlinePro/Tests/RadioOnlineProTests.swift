import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testNoVRTStreamsCanBeSelected() {
        XCTAssertEqual(StationCatalog.stations.count, 1)
        XCTAssertEqual(StationCatalog.stations[0].url, "https://radio.mdkband.com/stream.mp3")
        XCTAssertNil(StationCatalog.station(for: "https://icecast.vrtcdn.be/radio1-high.mp3"))
    }
    func testMigrationRemovesVRTStationsAndFavorites() throws {
        let defaults = UserDefaults.standard
        let oldStations = defaults.data(forKey: "stations")
        let oldFavorites = defaults.object(forKey: "favorites")
        defer { defaults.set(oldStations, forKey: "stations"); defaults.set(oldFavorites, forKey: "favorites") }
        let old = Station(name: "Radio 1", genre: "VRT", url: "https://icecast.vrtcdn.be/radio1-high.mp3")
        defaults.set(try JSONEncoder().encode([old]), forKey: "stations")
        defaults.set([old.id], forKey: "favorites")
        let model = RadioModel()
        XCTAssertTrue(model.stations.isEmpty)
        XCTAssertTrue(model.favorites.isEmpty)
        model.play(old)
        XCTAssertNil(model.current)
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
    func testLiveAdvertisingRequiresBothRightsAndPublisherReadiness() {
        let appID = "ca-app-pub-1234567890123456~1234567890"
        let bannerID = "ca-app-pub-1234567890123456/1234567890"
        for rights in [false, true] {
            for publisher in [false, true] {
                let config = AdvertisingConfiguration(appID: appID, bannerID: bannerID,
                    commercialRightsConfirmed: rights, publisherSetupComplete: publisher)
                XCTAssertEqual(config.permitsLiveAds, rights && publisher)
            }
        }
        XCTAssertFalse(AdvertisingConfiguration(appID: AdvertisingConfiguration.testAppID,
            bannerID: AdvertisingConfiguration.testBannerID, commercialRightsConfirmed: true,
            publisherSetupComplete: true).permitsLiveAds)
        XCTAssertFalse(AdvertisingConfiguration(appID: appID, bannerID: "invalid",
            commercialRightsConfirmed: true, publisherSetupComplete: true).permitsLiveAds)
        XCTAssertTrue(AdvertisingConfiguration.current.permitsTestAds)
        XCTAssertEqual(AdvertisingConfiguration.current.appID, "ca-app-pub-2792865707760596~4682819686")
        XCTAssertFalse(AdvertisingConfiguration.current.permitsLiveAds)
    }
    func testAttributionRequiresKnownLicenseSourceAndFreshMetadata() throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        func credit(release: String = "MDK001", source: String = "https://archive.org/details/mdk001-how-it-started", generated: Double = 1_800_000_000) -> MDKAttribution {
            MDKAttribution(ok: true, artist: "MDK", trackTitle: "Erste", releaseID: release,
                releaseTitle: "How it started", archiveDetailsURL: source, generatedAt: generated)
        }
        XCTAssertEqual(MDKAttribution.licensedReleases.count, 149)
        XCTAssertNoThrow(try credit().validated(at: now))
        XCTAssertThrowsError(try credit(release: "UNKNOWN").validated(at: now))
        XCTAssertThrowsError(try credit(source: "https://other.example/music").validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 - 121).validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 + 121).validated(at: now))
        for record in MDKAttribution.licensedReleases.values {
            XCTAssertEqual(record.licenseURL, MDKAttribution.licenseURL)
            XCTAssertEqual(URL(string: record.sourceURL)?.host, "archive.org")
        }
    }
}
