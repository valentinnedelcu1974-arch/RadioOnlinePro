# No-VRT draft rights register

No stations enabled. No commercial streaming permission asserted. The earlier VRT request was sent but its result is no longer a requirement for a future VRT-free catalog. Replacement stations must have documented permissions before inclusion.
