import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testPublishedCatalogAndAttributionScope() {
        XCTAssertEqual(StationCatalog.stations.count, 22)
        let vrt = StationCatalog.station(for: "https://icecast.vrtcdn.be/radio1-high.mp3")!
        XCTAssertFalse(StationCatalog.requiresAttribution(vrt))
        let mdk = StationCatalog.station(for: "https://radio.mdkband.com/stream.mp3")!
        XCTAssertTrue(StationCatalog.requiresAttribution(mdk))
        XCTAssertNil(StationCatalog.station(for: "https://unknown.example/live.mp3"))
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
    func testAttributionRequiresKnownLicenseSourceAndFreshMetadata() throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        func credit(release: String = "MDK001", source: String = "https://archive.org/details/mdk001-how-it-started", generated: Double = 1_800_000_000) -> MDKAttribution {
            MDKAttribution(ok: true, artist: "MDK", trackTitle: "Erste", releaseID: release,
                releaseTitle: "How it started", archiveDetailsURL: source, generatedAt: generated)
        }
        XCTAssertEqual(MDKAttribution.licensedReleases.count, 149)
        XCTAssertNoThrow(try credit().validated(at: now))
        XCTAssertThrowsError(try credit(release: "UNKNOWN").validated(at: now))
        XCTAssertThrowsError(try credit(source: "https://other.example/music").validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 - 121).validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 + 121).validated(at: now))
        for record in MDKAttribution.licensedReleases.values {
            XCTAssertEqual(record.licenseURL, MDKAttribution.licenseURL)
            XCTAssertEqual(URL(string: record.sourceURL)?.host, "archive.org")
        }
    }
    func testRomanianDirectoryFiltersInvalidEntriesAndDeduplicatesStreams() throws {
        func record(name: String = "Radio Constanța", country: String = "RO", codec: String = "MP3", ok: Int = 1, url: String = "https://stream.example.org/constanta") -> RomanianDirectory.Record {
            RomanianDirectory.Record(stationuuid: "00000000-0000-4000-8000-000000000001", name: name, url: url,
                url_resolved: url, homepage: "https://www.radioconstanta.ro/", tags: "regional,știri", countrycode: country, codec: codec, lastcheckok: ok)
        }
        let result = RomanianDirectory.stations(from: [record(), record(name: "Duplicate"), record(country: "BE"),
            record(codec: "OGG"), record(ok: 0), record(url: "http://stream.example.org/plain"),
            record(url: "https://user:pass@stream.example.org/private")])
        XCTAssertEqual(result.count, 1)
        XCTAssertEqual(result.first?.countryCode, "RO")
        XCTAssertEqual(result.first?.name, "Radio Constanța")
        XCTAssertEqual(result.first?.sourceURL?.host, "www.radioconstanta.ro")
        XCTAssertFalse(StationCatalog.requiresAttribution(result[0]))
        let decoded = try JSONDecoder().decode([Station].self, from: JSONEncoder().encode(result))
        XCTAssertEqual(RomanianDirectory.validatedCache(decoded), result)
        XCTAssertTrue(RomanianDirectory.validatedCache([Station(name: "Not a directory record", genre: "", url: "https://example.org/live")]).isEmpty)
    }
    func testRomanianDirectoryLiveCatalog() async throws {
        let found = try await RomanianDirectory.load()
        XCTAssertGreaterThan(found.count, 10, "Live RO directory should contain a meaningful national catalog")
        XCTAssertTrue(found.allSatisfy { $0.isRomanian && RomanianDirectory.validStream($0.url) != nil })
        XCTAssertEqual(Set(found.map(\.id)).count, found.count)
        XCTAssertTrue(found.contains { $0.name.localizedCaseInsensitiveContains("Constan") }, "Constanța must be discoverable")
        print("ROMANIAN_DIRECTORY_COUNT=\(found.count)")
        print("ROMANIAN_DIRECTORY_SAMPLE=\(found.prefix(10).map(\.name).joined(separator: "; "))")
    }

}
