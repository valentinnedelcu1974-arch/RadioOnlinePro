import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testPublishedCatalogAndAttributionScope() {
        XCTAssertEqual(StationCatalog.stations.count, 22)
        let vrt = StationCatalog.station(for: "https://icecast.vrtcdn.be/radio1-high.mp3")!
        XCTAssertFalse(StationCatalog.requiresAttribution(vrt))
        let mdk = StationCatalog.station(for: "https://radio.mdkband.com/stream.mp3")!
        XCTAssertTrue(StationCatalog.requiresAttribution(mdk))
        XCTAssertNil(StationCatalog.station(for: "https://unknown.example/live.mp3"))
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
    func testAttributionRequiresKnownLicenseSourceAndFreshMetadata() throws {
        let now = Date(timeIntervalSince1970: 1_800_000_000)
        func credit(release: String = "MDK001", source: String = "https://archive.org/details/mdk001-how-it-started", generated: Double = 1_800_000_000) -> MDKAttribution {
            MDKAttribution(ok: true, artist: "MDK", trackTitle: "Erste", releaseID: release,
                releaseTitle: "How it started", archiveDetailsURL: source, generatedAt: generated)
        }
        XCTAssertEqual(MDKAttribution.licensedReleases.count, 149)
        XCTAssertNoThrow(try credit().validated(at: now))
        XCTAssertThrowsError(try credit(release: "UNKNOWN").validated(at: now))
        XCTAssertThrowsError(try credit(source: "https://other.example/music").validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 - 121).validated(at: now))
        XCTAssertThrowsError(try credit(generated: now.timeIntervalSince1970 + 121).validated(at: now))
        for record in MDKAttribution.licensedReleases.values {
            XCTAssertEqual(record.licenseURL, MDKAttribution.licenseURL)
            XCTAssertEqual(URL(string: record.sourceURL)?.host, "archive.org")
        }
    }
}
