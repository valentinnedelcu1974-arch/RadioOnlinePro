import Foundation

struct MDKLicensedRelease: Decodable {
    let sourceURL: String
    let licenseURL: String
}

struct MDKAttribution: Decodable {
    let ok: Bool
    let artist: String
    let trackTitle: String
    let releaseID: String
    let releaseTitle: String
    let archiveDetailsURL: String
    let generatedAt: Double
    var sourceURL: URL? { URL(string: archiveDetailsURL) }
    enum CodingKeys: String, CodingKey {
        case ok, artist
        case trackTitle = "track_title", releaseID = "release_id", releaseTitle = "release_title"
        case archiveDetailsURL = "archive_details_url", generatedAt = "generated_at_unix"
    }
    enum ValidationError: Error { case unavailable, unverified }
    static let licenseURL = "https://creativecommons.org/licenses/by/3.0/"
    static let licensedReleases: [String: MDKLicensedRelease] = {
        guard let url = Bundle.main.url(forResource: "MDKLicensedReleases", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let records = try? JSONDecoder().decode([String: MDKLicensedRelease].self, from: data) else { return [:] }
        return records
    }()
    func validated(at now: Date = Date()) throws -> Self {
        guard ok, artist == "MDK", !trackTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !releaseTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              generatedAt.isFinite, abs(now.timeIntervalSince1970 - generatedAt) <= 120,
              let release = Self.licensedReleases[releaseID], release.licenseURL == Self.licenseURL,
              archiveDetailsURL == release.sourceURL,
              let sourceURL, sourceURL.scheme == "https", sourceURL.host == "archive.org" else {
            throw ValidationError.unverified
        }
        return self
    }
    static func load() async throws -> Self {
        let url = URL(string: "https://radio.mdkband.com/now-playing.json")!
        var request = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 10)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              http.url?.scheme == "https", http.url?.host == "radio.mdkband.com", data.count <= 512_000 else {
            throw ValidationError.unavailable
        }
        return try JSONDecoder().decode(Self.self, from: data).validated()
    }
}
