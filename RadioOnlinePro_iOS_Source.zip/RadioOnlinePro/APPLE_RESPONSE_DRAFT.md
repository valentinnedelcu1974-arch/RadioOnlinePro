# Radio 43 — response candidate, NOT SENT

Do not submit this draft as a claim that the new candidate has shipped. Build 6 remains rejected. Candidate changes require macOS compilation, device beta feedback, and a refreshed screenshot set. Cross-app binary/source comparison is not completed.

Dear App Review Team,

Thank you for the detailed notice concerning Guidelines 4.3 and 4.2.6. We acknowledge that a generic radio player needs substantive differentiation. We are preparing changes and are not resubmitting the unchanged build 6. The answers below distinguish the rejected build from unsubmitted work.

1. Function and problem solved
Build 6 is a native iPhone player for one experimental electronic music stream, MDK Space Radio. It uses AVPlayer, background audio, system playback controls, AirPlay and a sleep timer. Its attribution validator checks live track/release metadata against a bundled register of licensed releases. Playback pauses if the required provenance is missing, stale or does not match a reviewed release/source. This addresses keeping original source and license attribution attached to a changing live stream. It does not record, download or rehost audio. A new candidate adds a local listening notebook, personal notes, text attribution export, and a searchable release-provenance register. These candidate features are not yet present in the reviewed build 6.

2. Intended audience
Listeners interested in independently released experimental electronic music who want to identify the currently playing release, retain a source reference for later research, and understand the associated Creative Commons attribution. The app is not an engineering tool, game, station-owner administration tool or a general worldwide station directory.

3. Differentiation and market need
Standard playback, favorites and a timer are not claimed to be unique. The proposed differentiated workflow is: verify the live release against a closed source/license register, save the verified track reference, annotate it locally, and export a complete attribution with original source, author credits and license. We do not claim that no competing app offers similar functions or that the present build alone proves a market gap. The candidate will be tested before any request to assess these improvements.

4. Testing and beta feedback
Before build 6 submission, the recorded GitHub CI run compiled the simulator app, passed six tests and installed/launched the app for a simulator screenshot. Stream checks also inspected live metadata and MP3 decoding. These are engineering checks, not an external beta programme. We currently have no verified Radio 43 physical-device beta feedback to cite and will not invent tester counts, quotations or feedback-driven changes. Device beta testing of the revised candidate is a remaining prerequisite; a factual test report and any applied fixes must be appended before resubmission.

5. Standalone or suite
Radio 43 is intended as a standalone music listening product, not one of multiple city/station reskins and not an expansion of the developer's engineering, procurement, communication utility or game apps. No account in those products is required. No common subscription or entitlement grants access across them. A verified account-wide comparison remains to be completed before making an exhaustive claim about every other app.

6. Consolidation into another app
We are not aware of another radio-listening product on this account from the project records reviewed. Adding this music workflow to an engineering or business utility would introduce an unrelated purpose and audience. The radio app has no in-app purchase products in build 6. This is a product-scope explanation, not a claim that consolidation is technically impossible. The final response must reflect the completed account inventory.

7. Shared components with apps on this account
The reviewed radio source includes its SwiftUI player, MDK metadata validator, licensed-release JSON, app icon/assets and an optional advertising integration. Apple system frameworks and Google Mobile Ads/UMP are used. An account-wide source/binary and asset comparison has not yet been performed; we cannot truthfully certify that there are no other significant shared components. This comparison must be completed and any actual overlap itemized before a final answer is sent.

8. Shared components with third-party apps
The reviewed project uses Apple frameworks, Google Mobile Ads 13.12.0 and UMP 3.1.0. Its music stream, live metadata and source/license reference catalog originate from MDK Space Radio and are third-party content. The app does not claim to have composed this music or own the stream. The project records state that no MDK website frontend code, artist logos or artwork were copied. The independently implemented app behavior is native playback, strict live-attribution checking, and, in the candidate only, the local notebook and provenance/export workflow. We do not claim exclusive access to the CC BY catalog.

9. Client, partner and origin
The visible development instructions identify this as the account holder's own radio-app project, not a commissioned app for MDK or a client. It was developed with AI coding assistance under the account holder's direction; we do not represent it as entirely manually authored. MDK provides the third-party music/catalog; Music by MDK — Mik Schuppin, Diego Madero & Kai Kraatz, with CC BY 3.0 attribution. No MDK sponsorship, endorsement or commissioning relationship is claimed. CC BY licensing and attribution do not by themselves establish compliance with Guideline 4.2.6. We request evaluation of the actual custom native workflow and will provide accurate source/provenance and test evidence.

We understand that the approval decision rests with App Review. We will not resubmit the unchanged binary or represent untested candidate features as shipped functionality.
