import Foundation

/// Community directory metadata only; audio is delivered by each station, not Radio Browser.
enum RomanianDirectory {
    struct Record: Decodable {
        let stationuuid: String
        let name: String
        let url: String
        let url_resolved: String
        let homepage: String
        let tags: String
        let countrycode: String
        let codec: String
        let lastcheckok: Int
    }
    enum DirectoryError: Error { case invalidResponse, noPlayableStations }
    static let bootstrapHost = "de1.api.radio-browser.info"
    static let supportedCodecs: Set<String> = ["MP3", "AAC", "AAC+", "AACP", "FLAC", "ALAC"]

    static func validStream(_ value: String) -> URL? {
        guard let url = URL(string: value.trimmingCharacters(in: .whitespacesAndNewlines)),
              url.scheme?.lowercased() == "https", let host = url.host, !host.isEmpty,
              url.user == nil, url.password == nil else { return nil }
        return url
    }
    static func stations(from records: [Record]) -> [Station] {
        var seen = Set<String>()
        return records.compactMap { record -> Station? in
            let name = record.name.trimmingCharacters(in: .whitespacesAndNewlines)
            guard record.countrycode.uppercased() == "RO", record.lastcheckok == 1,
                  supportedCodecs.contains(record.codec.uppercased()), !name.isEmpty,
                  UUID(uuidString: record.stationuuid) != nil,
                  let stream = validStream(record.url_resolved) ?? validStream(record.url),
                  seen.insert(stream.absoluteString).inserted else { return nil }
            let tags = record.tags.split(separator: ",").prefix(3).joined(separator: " · ")
            let page = validStream(record.homepage)?.absoluteString
            return Station(name: name, genre: "România" + (tags.isEmpty ? "" : " · " + tags),
                url: stream.absoluteString, countryCode: "RO", homepage: page, directoryID: record.stationuuid)
        }.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
    static func validatedCache(_ input: [Station]) -> [Station] {
        var seen = Set<String>()
        return input.filter {
            $0.countryCode == "RO" && UUID(uuidString: $0.directoryID ?? "") != nil &&
            !$0.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
            validStream($0.url) != nil && seen.insert($0.url).inserted
        }
    }
    private static func request(_ url: URL) async throws -> Data {
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("Radio43/1.0 (iOS; https://valentinnedelcu1974-arch.github.io/)", forHTTPHeaderField: "User-Agent")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, (200..<300).contains(response.statusCode) else { throw DirectoryError.invalidResponse }
        return data
    }
    static func load() async throws -> [Station] {
        // Obtain the complete RO result set, not a popularity-limited search.
        // Server discovery permits failover to official API hosts only.
        struct Server: Decodable { let name: String }
        var hosts = [bootstrapHost]
        if let data = try? await request(URL(string: "https://\(bootstrapHost)/json/servers")!),
           let servers = try? JSONDecoder().decode([Server].self, from: data) {
            hosts += servers.map(\.name).filter { host in
                host.hasSuffix(".api.radio-browser.info") && host.allSatisfy { $0.isASCII && ($0.isLetter || $0.isNumber || $0 == "." || $0 == "-") } && host != bootstrapHost
            }.shuffled().prefix(2)
        }
        var failure: Error = DirectoryError.noPlayableStations
        for host in hosts {
            try Task.checkCancellation()
            var url = URLComponents(string: "https://\(host)/json/stations/bycountrycodeexact/RO")!
            url.queryItems = [URLQueryItem(name: "hidebroken", value: "true"),
                URLQueryItem(name: "order", value: "name"), URLQueryItem(name: "limit", value: "100000")]
            do {
                let data = try await request(url.url!)
                try Task.checkCancellation()
                let found = stations(from: try JSONDecoder().decode([Record].self, from: data))
                guard !found.isEmpty else { throw DirectoryError.noPlayableStations }
                return found
            } catch is CancellationError { throw CancellationError() }
              catch { failure = error }
        }
        throw failure
    }
}
