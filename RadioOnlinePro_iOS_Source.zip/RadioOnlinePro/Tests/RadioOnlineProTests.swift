import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testCatalogHasOnlyOfficialUniqueVRTStreams() {
        XCTAssertFalse(StationCatalog.stations.isEmpty)
        XCTAssertEqual(Set(StationCatalog.stations.map(\.id)).count, StationCatalog.stations.count)
        for station in StationCatalog.stations {
            XCTAssertEqual(RadioModel.validURL(station.url)?.host, "icecast.vrtcdn.be")
            XCTAssertNotNil(StationCatalog.station(for: station.url))
        }
        XCTAssertNil(StationCatalog.station(for: "https://radio.example.org/live.mp3"))
    }
    func testMigrationRemovesUnapprovedSavedStations() throws {
        let defaults = UserDefaults.standard
        let oldStations = defaults.data(forKey: "stations")
        let oldFavorites = defaults.object(forKey: "favorites")
        defer { defaults.set(oldStations, forKey: "stations"); defaults.set(oldFavorites, forKey: "favorites") }
        let allowed = StationCatalog.stations[0]
        let unknown = Station(name: "Unknown", genre: "", url: "https://radio.example.org/live.mp3")
        defaults.set(try JSONEncoder().encode([allowed, unknown]), forKey: "stations")
        defaults.set([allowed.id, unknown.id], forKey: "favorites")
        let model = RadioModel()
        XCTAssertEqual(model.stations, [allowed])
        XCTAssertEqual(model.favorites, Set([allowed.id]))
        model.play(unknown)
        XCTAssertNil(model.current)
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
}
