# Radio 43 — source and permission register

Reviewed 10 November 2026. Free app with no ads, purchases, recording or rehosting. No paid license purchased.

## VRT — 21 direct streams
Official source: https://www.vrt.be/nl/ons-aanbod/streamingslinks-radio . VRT explicitly publishes streaming URLs so listeners can continue listening using smaller apps and services. We rely on this specific publication for direct unmodified listening in this free, non-monetized app. General terms: https://www.vrt.be/nl/info/gebruiksvoorwaarden . This is not a commercial music license, ownership transfer, endorsement, or permission to record, remix, rehost, copy artwork or use logos. Broadcaster-owned ads remain in the unchanged stream. Territory restrictions and availability remain provider-controlled. Recheck permission before any future monetization.

## MDK Space Radio
Music by MDK — Mik Schuppin, Diego Madero & Kai Kraatz. Original music published under CC BY 3.0 at https://radio.mdkband.com/ and https://github.com/sigilabcodex/mdk-space-radio . The bundled register contains 149 source/license records. Live metadata must match a reviewed release, original archive.org source and fresh timestamp; invalid/unavailable metadata stops only MDK playback. Attribution and original source/license links are displayed. No frontend code, artist logos or artwork copied. No endorsement. Notebook saves text references only, never audio.

Provider publication supports the described use but does not guarantee App Store approval or constitute a worldwide warranty of third-party rights.

## Closed catalog after build 10
The candidate removes Radio Browser discovery and cached stations, maps saved favorites to bundled URLs, and includes zero Romanian third-party streams. The broadcast observation log stores listener-authored text locally.
