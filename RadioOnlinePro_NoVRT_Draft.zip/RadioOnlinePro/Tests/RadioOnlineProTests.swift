import XCTest
@testable import RadioOnlinePro

@MainActor final class RadioOnlineProTests: XCTestCase {
    func testStreamURLValidation() {
        XCTAssertNotNil(RadioModel.validURL(" https://radio.example.org/live.mp3 "))
        XCTAssertNil(RadioModel.validURL("http://radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("https:///"))
        XCTAssertNil(RadioModel.validURL("https://user:password@radio.example.org/live"))
        XCTAssertNil(RadioModel.validURL("file:///tmp/audio.mp3"))
    }
    func testNoVRTStreamsCanBeSelected() {
        XCTAssertTrue(StationCatalog.stations.isEmpty)
        XCTAssertNil(StationCatalog.station(for: "https://icecast.vrtcdn.be/radio1-high.mp3"))
    }
    func testMigrationRemovesVRTStationsAndFavorites() throws {
        let defaults = UserDefaults.standard
        let oldStations = defaults.data(forKey: "stations")
        let oldFavorites = defaults.object(forKey: "favorites")
        defer { defaults.set(oldStations, forKey: "stations"); defaults.set(oldFavorites, forKey: "favorites") }
        let old = Station(name: "Radio 1", genre: "VRT", url: "https://icecast.vrtcdn.be/radio1-high.mp3")
        defaults.set(try JSONEncoder().encode([old]), forKey: "stations")
        defaults.set([old.id], forKey: "favorites")
        let model = RadioModel()
        XCTAssertTrue(model.stations.isEmpty)
        XCTAssertTrue(model.favorites.isEmpty)
        model.play(old)
        XCTAssertNil(model.current)
    }
    func testStationIdentityUsesStreamRatherThanName() {
        let first = Station(name: "Radio", genre: "Pop", url: "https://one.example.org/live")
        let second = Station(name: "Radio", genre: "Pop", url: "https://two.example.org/live")
        XCTAssertNotEqual(first.id, second.id)
        XCTAssertEqual(first.id, Station(name: "Renamed", genre: "Rock", url: first.url).id)
    }
    func testLiveAdvertisingRequiresBothRightsAndPublisherReadiness() {
        let appID = "ca-app-pub-1234567890123456~1234567890"
        let bannerID = "ca-app-pub-1234567890123456/1234567890"
        for rights in [false, true] {
            for publisher in [false, true] {
                let config = AdvertisingConfiguration(appID: appID, bannerID: bannerID,
                    commercialRightsConfirmed: rights, publisherSetupComplete: publisher)
                XCTAssertFalse(config.permitsLiveAds, "An empty catalog cannot enable live advertising")
            }
        }
        XCTAssertFalse(AdvertisingConfiguration(appID: AdvertisingConfiguration.testAppID,
            bannerID: AdvertisingConfiguration.testBannerID, commercialRightsConfirmed: true,
            publisherSetupComplete: true).permitsLiveAds)
        XCTAssertFalse(AdvertisingConfiguration(appID: appID, bannerID: "invalid",
            commercialRightsConfirmed: true, publisherSetupComplete: true).permitsLiveAds)
        XCTAssertTrue(AdvertisingConfiguration.current.permitsTestAds)
        XCTAssertEqual(AdvertisingConfiguration.current.appID, "ca-app-pub-2792865707760596~4682819686")
        XCTAssertFalse(AdvertisingConfiguration.current.permitsLiveAds)
    }
}
